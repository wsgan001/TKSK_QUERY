package DATA;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;

public class D {

	public D() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param args
	 * @throws Exception 
	 */
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		BufferedReader reader=new BufferedReader(new FileReader("E:/WorkSpace_MyEclipse/LAB_CPP/CODE/Code_Win32/GTree/GTree/CTR.cedge"));
		
		String line;
		String oldline = "";
		while((line=reader.readLine())!=null)
		{
			oldline=line;
		}
		System.out.println(oldline);
		reader.close();
		
	}

}
