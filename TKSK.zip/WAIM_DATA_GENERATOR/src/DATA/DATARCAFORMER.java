package DATA;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.Random;

import Utils.waimDataConfigure;

public class DATARCAFORMER {

	public DATARCAFORMER() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param args
	 * @throws Exception 
	 */
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		
		BufferedReader reader=new BufferedReader(new FileReader(waimDataConfigure.POI_F_P+waimDataConfigure.dataSize+".txt"));
		String line;
		FileWriter fw=new FileWriter(waimDataConfigure.POI_F_P+waimDataConfigure.ROAD_NETWORK+"/"+waimDataConfigure.ROAD_NETWORK+"_"+waimDataConfigure.dataSize+".txt");
		Random rand=new Random();
		while((line=reader.readLine())!=null)
		{
			String[] datas=line.split(" ");
			int vertex=rand.nextInt(waimDataConfigure.maxVerte);
			String newline=vertex+" "+datas[2]+" "+datas[3];
			for(int i=4;i<datas.length;i++)
			{
				newline+=" "+datas[i]+" 1";
			}
			newline+="\r\n";
			fw.write(newline);
		}
		reader.close();
		fw.close();
		
	}

}
