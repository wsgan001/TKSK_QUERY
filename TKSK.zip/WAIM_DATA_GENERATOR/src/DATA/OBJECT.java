package DATA;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class OBJECT {

	public OBJECT() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param args
	 * @throws Exception 
	 */
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub

		BufferedReader reader=new BufferedReader(new FileReader("E:\\WorkSpace_MyEclipse\\LAB_CPP\\CODE\\Code_Win32\\GTree\\GTree\\FLA.cnode"));
		FileWriter fw=new FileWriter("E:/S_FLA.object");
		String line;
		int ii=0;
//		while((line=reader.readLine())!=null)
//		{
//			String[] lined=line.split(" ");
//			fw.write(lined[0]+" "+ii+"\r\n");
//			ii++;
//			
//		}
		for(int i=0;i<1070376;i++)
		{
			fw.write(i+" "+i+"\r\n");
		}
		fw.close();
		reader.close();
	}

}
