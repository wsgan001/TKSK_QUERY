package Interface_queryDATA;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.HashMap;
import java.util.Random;
import java.util.Vector;

import Utils.waimDataConfigure;

public class queryGenerator {

	public HashMap<String, Integer> kwdCount;
	public HashMap<Integer, String> kwdIndex;
	
	public queryGenerator() throws Exception {
		// TODO Auto-generated constructor stub
		init();
		kwdCounter();
		for(int i=1;i<waimDataConfigure.queyKeyWordMaxNum;i++)
		{
			QueryGeneratorRun(i);
		}
		
	}
	
	public void init()
	{
		kwdCount=new HashMap<String, Integer>();
		kwdIndex=new HashMap<Integer, String>();
	}
	public void QueryGeneratorRun(int kwd) throws Exception
	{
		
		Random rand=new Random();
		Random randVertex=new Random();
		int maxkwdid=kwdIndex.size();
		FileWriter fw=new FileWriter(waimDataConfigure.queryFolder+waimDataConfigure.dataSize+"/"+waimDataConfigure.ROAD_NETWORK+"_DataSize_"+waimDataConfigure.dataSize+"_kwdNum_"+kwd+".txt");
		
		for(int i=0;i<waimDataConfigure.itro;i++)
		{
			Vector<String> kwds=new Vector<String>();
			int vertexID=randVertex.nextInt(waimDataConfigure.maxVerte);
			String QueryLine=vertexID+" "+"53.68604487 -113.23043898";
			while(kwds.size()<kwd)
			{
				int kwdid=rand.nextInt(maxkwdid);
				if(kwds.contains(kwdIndex.get(kwdid)))
				{
					
				}else
				{
					kwds.add(kwdIndex.get(kwdid));
					QueryLine+=" "+kwdIndex.get(kwdid)+" 1";
					
				}
			}
			
			fw.write(QueryLine+"\r\n");
		}
		fw.close();
	}
	
	public void kwdCounter() throws Exception
	{
		BufferedReader reader=new BufferedReader(new FileReader("E:/WorkSpace_Data_LAB/LAB_DATA/WAIM2015/POI/London/london_"+waimDataConfigure.dataSize+".txt"));
		
		String line;
		int  indexCounter=1;
		
		int docCounter=0;
		int wordCounter=0;
		while((line=reader.readLine())!=null)
		{
			String[] datas=line.split(" ");
			for(int i=3;i<datas.length;i=i+2)
			{
				if(kwdCount.containsKey(datas[i]))
				{
					int tmp=kwdCount.get(datas[i])+1;
					kwdCount.put(datas[i], tmp);
				}
				else
				{
					kwdCount.put(datas[i], 1);
					kwdIndex.put(indexCounter, datas[i]);
					indexCounter++;
				}
				wordCounter++;
			}
			docCounter++;
		}
		reader.close();
		System.out.println("AVG:"+(wordCounter*1.0f/docCounter));
		System.out.println("Distinct:"+kwdIndex.size());
		
	}
	
	
	/**
	 * @param args
	 * @throws Exception 
	 */
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		queryGenerator test=new queryGenerator();
		
	}

}
