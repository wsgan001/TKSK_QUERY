package ROAD;

public class EDGE {
	public  int id;
	public int v1;
	public int v2;
	public double weight;

	public EDGE(int id,int v1,int v2,double weight) {
		// TODO Auto-generated constructor stub
		this.v1=v1;
		this.v2=v2;
		this.id=id;
		this.weight=weight;
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
