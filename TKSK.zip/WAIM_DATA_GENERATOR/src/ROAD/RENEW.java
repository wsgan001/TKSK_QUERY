package ROAD;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.HashMap;
import java.util.Vector;

public class RENEW {

	public RENEW() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param args
	 * @throws Exception 
	 */
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub

		HashMap<Integer, Integer> vertexNewID=new HashMap<Integer, Integer>();
		Vector<EDGE> edge=new Vector<EDGE>();
		
		
		BufferedReader reader=new BufferedReader(new FileReader("E:/WorkSpace_Data_LAB/LAB_DATA/WAIM2015/RoadNetwork/FLA/FLA.cedge"));
		String line;
		BufferedReader reader2=new BufferedReader(new FileReader("E:/WorkSpace_Data_LAB/LAB_DATA/WAIM2015/RoadNetwork/FLA/FLA.cnode"));
		
		FileWriter fw=new FileWriter("E:/WorkSpace_Data_LAB/LAB_DATA/WAIM2015/RoadNetwork/FLA/S_FLA.cedge");
		FileWriter fw2=new FileWriter("E:/WorkSpace_Data_LAB/LAB_DATA/WAIM2015/RoadNetwork/FLA/S_FLA.cnode");
		
		while((line=reader.readLine())!=null)
		{
			String[] datas=line.split(" ");
			int edgeID=Integer.parseInt(datas[0]);
			int V1ID=Integer.parseInt(datas[1]);
			int V2ID=Integer.parseInt(datas[2]);
			double weight=Double.parseDouble(datas[3]);
//			EDGE edgeC=new EDGE(edgeID, V1ID, V2ID, weight);
			edge.add(new EDGE(edgeID, V1ID, V2ID, weight));
		}
		reader.close();
		int vidCounter=0; 
		
		while((line=reader2.readLine())!=null)
		{
			String[] datas=line.split(" ");
			int vid=Integer.parseInt(datas[0]);
			if(!vertexNewID.containsKey(vid))
			{
				vertexNewID.put(vid, vidCounter);
				fw2.write(vidCounter+" "+datas[1]+" "+datas[2]+"\r\n");
				vidCounter++;
			}
		}
		fw2.close();
		reader.close();
		
		for(int i=0;i<edge.size();i++)
		{
			String lineE=i+" "+vertexNewID.get(edge.get(i).v1)+" "+vertexNewID.get(edge.get(i).v2)+" "+edge.get(i).weight+"\r\n";
			fw.write(lineE);
		}
		fw.close();
	}

}
