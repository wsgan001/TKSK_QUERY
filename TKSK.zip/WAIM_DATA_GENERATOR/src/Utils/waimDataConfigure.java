package Utils;

public class waimDataConfigure {
	
//	public static String POIPath="E:/WorkSpace_Data_LAB/LAB_DATA/WAIM2015/POI/200K.txt";
	public static String queryFolder="E:/WorkSpace_Data_LAB/LAB_DATA/WAIM2015/Query/";
	
	public static int queyKeyWordMaxNum=10;
	public static int  itro=50;
	public static int maxVerte=1069943;
	public static String ROAD_NETWORK="FLA";
	
	public static String POI_F_P="E:/WorkSpace_Data_LAB/LAB_DATA/WAIM2015/POI/";
	public static String dataSize="100K";
	
	
	
}
