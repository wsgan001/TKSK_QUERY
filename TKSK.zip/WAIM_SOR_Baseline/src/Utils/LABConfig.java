package Utils;

public class LABConfig {
	/*  data configure begin*/
	public static String DATA_ROOT_FOLDER_PATH="E:/WorkSpace_Data_LAB/LAB_DATA/WAIM2015/";
	
	public static String DATA_VERTEX_PATH="E:/WorkSpace_Data_LAB/LAB_DATA/WAIM2015/RoadNetwork/FLA/FLA.cnode";
	
	public static String DATA_EDGE_PATH="E:/WorkSpace_Data_LAB/LAB_DATA/WAIM2015/RoadNetwork/FLA/FLA.cedge";
	
	public static String DATA_POI_PATH="E:/WorkSpace_Data_LAB/LAB_DATA/WAIM2015/POI/";
	
	
	
	/*  data configure end*/
	
	/*  Index configure start*/
	public static String INDEX_FOLDER="Index/";
//	public static String INDEX_NAME="Index_";
	public static String INDEX_VERTEX_POI_DB_NAME="vertexPOI";
	public static String INDEX_VERTEX_EDGE_DB_NAME="vertexEdge";
	public static String ROAD_NETWORK="FLA";
	/*  Index configure end*/
	
	
	/*  query configure begin*/
	public static String QUERY_FILE_FOLDER="Query/";
//	public static String QUERY_FILE_PATH="query.txt";
	public static float QUERY_SHREHOD=(float) 0.4;
	public static int TopK=10;
	
	public static String dataSize="100K";
	public static String queryNum="3";
	
	
	/*  query configure end*/
	
	public static String DATA_POI_SPLIT_FLAG=" ";
}
