package elements;
/**
 * POI
 * @author BYRD
 *
 */
public class CandidateResult implements Comparable<CandidateResult>{
	public int id;//POI id
	public double distance;
	public CandidateResult(int id,double distance) {
		// TODO Auto-generated constructor stub
		this.id=id;
		this.distance=distance;
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

	@Override
	public int compareTo(CandidateResult o) {
		// TODO Auto-generated method stub
		if(this.distance==o.distance)
		{
			return 0;
		}else if(this.distance>o.distance)
		{
			return 1;
		}else
		{
			return -1;
		}
	}

}
