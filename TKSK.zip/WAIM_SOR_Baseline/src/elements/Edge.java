package elements;

import java.io.Serializable;

public class Edge implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = -706928305577745261L;
	public int id_edge;
	public int id_vertex_start;
	public int id_vertex_end;
	public double distance;

	public Edge(int id,int start,int end,double distance) {
		// TODO Auto-generated constructor stub
		this.id_edge=id;
		this.id_vertex_end=end;
		this.id_vertex_start=start;
		this.distance=distance;
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
