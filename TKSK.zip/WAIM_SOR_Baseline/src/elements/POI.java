package elements;

import java.io.Serializable;
import java.util.HashMap;

public class POI implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = -8784321271119809124L;
	public int id;
	public HashMap<String, Float> textScore;
	
	
	public POI(int id,HashMap<String, Float> textScore) {
		// TODO Auto-generated constructor stub
		this.id=id;
		this.textScore=textScore;
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
