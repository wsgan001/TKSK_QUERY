package elements;

import java.io.Serializable;

public class Vertex implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = -2763983371676105397L;
	public int id_vertex;
	public double x;
	public double y;

	public Vertex() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
