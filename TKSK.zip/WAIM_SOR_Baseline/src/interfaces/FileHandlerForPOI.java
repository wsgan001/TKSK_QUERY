package interfaces;

public class FileHandlerForPOI {

	public FileHandlerForPOI() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
