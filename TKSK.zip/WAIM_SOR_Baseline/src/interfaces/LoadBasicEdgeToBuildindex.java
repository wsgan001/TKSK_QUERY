package interfaces;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.LineNumberReader;
import java.io.UnsupportedEncodingException;
import java.util.HashMap;

import org.mapdb.DB;
import org.mapdb.DBMaker;
import org.mapdb.HTreeMap;

import Utils.LABConfig;

import elements.Edge;
import elements.POI;

public class LoadBasicEdgeToBuildindex {

	public  HashMap<Integer,HashMap<Integer, Edge>> vertexEdgeMap;
	
	public  HashMap<Integer, HashMap<Integer, POI>> vertexPOIMap;
	
	public HTreeMap<Integer, HashMap<Integer, POI>> db_vertexPOIMap;
	
	public HTreeMap<Integer,HashMap<Integer, Edge>> db_vertexEdgeMap;
	
	
	public DB DB_Baseline;
	public String DB_Baseline_Name;

	public LoadBasicEdgeToBuildindex() throws IOException {
		// TODO Auto-generated constructor stub
		init();
	}
	
	
	public void init() throws IOException
	{
		vertexEdgeMap=new HashMap<Integer, HashMap<Integer,Edge>>();
		vertexPOIMap=new HashMap<Integer, HashMap<Integer,POI>>();
		DB_Baseline_Name=LABConfig.DATA_ROOT_FOLDER_PATH+LABConfig.INDEX_FOLDER+LABConfig.ROAD_NETWORK+"_"+LABConfig.dataSize;
		CreateDB();
		db_vertexPOIMap=DB_Baseline.getHashMap(LABConfig.INDEX_VERTEX_POI_DB_NAME);
		db_vertexEdgeMap=DB_Baseline.getHashMap(LABConfig.INDEX_VERTEX_EDGE_DB_NAME);
		loadEdges();
		loadPOI();
		saveDate();
	}
	
//	public void loadVertexs() throws IOException
//	{
//		LineNumberReader lineReader=new LineNumberReader(new FileReader(LABConfig.DATA_VERTEX_PATH));
//	}
	
	public void loadPOI() throws IOException
	{
//		LineNumberReader lineReader=new LineNumberReader(new FileReader(LABConfig.DATA_POI_PATH));
		// TODO Auto-generated method stub
				InputStreamReader isr = null;
				try {
					isr = new InputStreamReader(new FileInputStream(LABConfig.DATA_POI_PATH+LABConfig.ROAD_NETWORK+"/"+LABConfig.ROAD_NETWORK+"_"+LABConfig.dataSize+".txt"), "UTF-8");
				} catch (UnsupportedEncodingException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (FileNotFoundException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
				LineNumberReader lineReader=new LineNumberReader(isr);
				String line;
				
				int poiID=1;
				
				while((line=lineReader.readLine())!=null)
				{
					String[] parts=line.split(LABConfig.DATA_POI_SPLIT_FLAG);
					if(parts.length%2==0)
					{
						System.out.println(line);
						continue;
					}

					int vertexID=Integer.parseInt(parts[0]);
					
					//random
					
					double x=Double.parseDouble(parts[1]);
					double y=Double.parseDouble(parts[2]);
					HashMap<String, Float> kwdScore=new HashMap<String, Float>();
					HashMap<String, Integer> kwdCount = new HashMap<String, Integer>();
					for(int i=3;i<parts.length;i+=2)
					{
						String kwd = parts[i];
						
						int freq = Integer.parseInt(parts[i + 1]);
						if (kwdCount.containsKey(kwd)) {
							kwdCount.put(kwd, kwdCount.get(kwd) + freq);
						} else {
							kwdCount.put(kwd, freq);
						}
					}
					
					double sumeOfWeightSquare = 0;
					double weight;
					for (String kwd : kwdCount.keySet()) {
						int freq = kwdCount.get(kwd);
						weight = 1 + Math.log(freq);
						sumeOfWeightSquare += weight * weight;
					}
					sumeOfWeightSquare = Math.sqrt(sumeOfWeightSquare);	
					for (String kwd : kwdCount.keySet())
					{
						int freq = kwdCount.get(kwd);
						float textScore=(float) ((1 + Math.log(freq))/ sumeOfWeightSquare);
						kwdScore.put(kwd, textScore);
					}
					if(!vertexPOIMap.containsKey(vertexID))
					{
						vertexPOIMap.put(vertexID,new HashMap<Integer, POI>());
					}
					vertexPOIMap.get(vertexID).put(poiID,new POI(poiID, kwdScore));
					poiID++;
				}
				System.out.println(poiID);
	}
	
	public void loadEdges() throws IOException
	{
		LineNumberReader lineReader=new LineNumberReader(new FileReader(LABConfig.DATA_EDGE_PATH));
		String line;
		
		while((line=lineReader.readLine())!=null)
		{
			String[] parts=line.split(" ");
			if(parts.length<4)
			{
				System.err.println(line);
				System.err.println("Break");
				break;
			}
			int edgeID=Integer.parseInt(parts[0]);
			int startID=Integer.parseInt(parts[1]);
			int endID=Integer.parseInt(parts[2]);
			double distance=Double.parseDouble(parts[3]);
			if(!vertexEdgeMap.containsKey(startID))
			{
				vertexEdgeMap.put(startID, new HashMap<Integer, Edge>());
			}
			vertexEdgeMap.get(startID).put(edgeID, new Edge(edgeID, startID, endID, distance));
			if(!vertexEdgeMap.containsKey(endID))
			{
				vertexEdgeMap.put(endID, new HashMap<Integer, Edge>());
			}
			vertexEdgeMap.get(endID).put(edgeID, new Edge(edgeID, startID, endID, distance));
			
		}
		System.out.println("ver"+vertexEdgeMap.size());
	}
	
	public void CreateDB()
	{
		File dbFile = new File(DB_Baseline_Name);
        if(dbFile.exists()){
        	dbFile.delete();
        }
        DB_Baseline = DBMaker.newFileDB(dbFile)
        		//.asyncWriteEnable()
        		.transactionDisable()
        		.freeSpaceReclaimQ(0)
        		.asyncWriteEnable()
        		
        		//.cacheSize(1024*1024*100)
        		//.cacheLRUEnable()
        		//.cacheDisable()
        		//.fullChunkAllocationEnable()
        		//.mmapFileEnable()
        		//.syncOnCommitDisable()
        		.make();
        System.out.println("Created BD:\t"+DB_Baseline_Name);
	}

	public void saveDate()
	{
//		if(vertexPOIMap.containsKey(195431))
//		{
//			System.out.println(vertexPOIMap.get(195431).keySet());
//		}
		this.db_vertexEdgeMap.putAll(vertexEdgeMap);
		this.db_vertexPOIMap.putAll(vertexPOIMap);
		this.DB_Baseline.close();
	}
	
	
	
	/**
	 * @param args
	 * @throws IOException 
	 */
	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		LoadBasicEdgeToBuildindex test=new LoadBasicEdgeToBuildindex();

	}

}
