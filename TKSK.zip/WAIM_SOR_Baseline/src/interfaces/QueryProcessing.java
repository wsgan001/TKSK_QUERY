package interfaces;

import java.awt.Label;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.LineNumberReader;
import java.io.UnsupportedEncodingException;
import java.util.HashMap;
import java.util.HashSet;
import java.util.PriorityQueue;
import java.util.Vector;

import org.mapdb.DB;
import org.mapdb.DBMaker;
import org.mapdb.HTreeMap;

import elements.CandidateResult;
import elements.CandidateVertex;
import elements.Edge;
import elements.POI;

import Utils.LABConfig;

public class QueryProcessing {
	public DB DB_Baseline;
	public String DB_Baseline_Name;
	public HTreeMap<Integer, HashMap<Integer, POI>> db_vertexPOIMap;
	public HTreeMap<Integer,HashMap<Integer, Edge>> db_vertexEdgeMap;
	
	
	
	/*query flag begin*/
	public HashSet<Integer> queryVertexsVisited;
	public HashSet<Integer> queryEdgesVisited;
	public int TopK;
	public PriorityQueue<CandidateResult> resultTopK;
	public PriorityQueue<CandidateVertex> minHeap;
	public float shrehod=LABConfig.QUERY_SHREHOD;
	
	
	public int dataAccessed=0;
	public int totaldataAccessed=0;
	/*query flag end*/
	public QueryProcessing() {
		// TODO Auto-generated constructor stub
		init();
	}
	
	public void init()
	{
		DB_Baseline_Name=LABConfig.DATA_ROOT_FOLDER_PATH+LABConfig.INDEX_FOLDER+LABConfig.ROAD_NETWORK+"_"+LABConfig.dataSize;
		loadIndexDB();
	
		db_vertexEdgeMap=DB_Baseline.getHashMap(LABConfig.INDEX_VERTEX_EDGE_DB_NAME);
		
		db_vertexPOIMap=DB_Baseline.getHashMap(LABConfig.INDEX_VERTEX_POI_DB_NAME);
		
		resultTopK=new PriorityQueue<CandidateResult>();
		
		minHeap=new PriorityQueue<CandidateVertex>();
		
		queryEdgesVisited=new HashSet<Integer>();
		
		queryVertexsVisited=new HashSet<Integer>();
		
		this.TopK=LABConfig.TopK;
	}
	
	
	public void queryFile(String FileName) throws IOException
	{
		InputStreamReader isr = null;
		try {
			isr = new InputStreamReader(new FileInputStream(FileName), "UTF-8");
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		LineNumberReader lineReader=new LineNumberReader(isr);
		String line;
		int queryNum=0;
		long totalTime=0;
		totaldataAccessed=0;
		while((line=lineReader.readLine())!=null&&queryNum<20)
		{
			long start=System.currentTimeMillis();
			query(line);
			long end=System.currentTimeMillis();
			totalTime+=end-start;
			queryNum++;
			totaldataAccessed+=dataAccessed;
			printTopK();
			
		}
		System.err.println("=====================================================");
		System.err.println("AVG Data Acess"+totaldataAccessed/(queryNum*1.0));
		System.err.println("queryAVGTime:\t"+totalTime/queryNum*1.0);
		System.err.println("=====================================================");
	}
	
	
	public void printTopK()
	{
		int count=1;
		while(resultTopK.size()>0)
		{
			CandidateResult res=resultTopK.poll();
			System.out.println("Top:"+count+"\t"+res.id+"\t"+res.distance);
			count++;
		}
	}
	public void initQuery()
	{
		//���ó�ʼ����С  �����Ŀ϶���ǰ��Ĳ�
		resultTopK.clear();
		//����֮ǰ�Ѿ����ʵ�����
		queryEdgesVisited.clear();
		queryVertexsVisited.clear();
		dataAccessed=0;
		minHeap.clear();
		
	}
	
	public void query(String queryString)
	{
		
		initQuery();
		
		String[] parts=queryString.split(LABConfig.DATA_POI_SPLIT_FLAG);
		
		
		if(parts.length%2==0)
		{
			System.err.println(queryString);
			return;
		}
		int queryVertex=Integer.parseInt(parts[0]);
		minHeap.add(new CandidateVertex(queryVertex, 0));
//		System.out.println(queryVertex);
		Vector<String> kwds=new Vector<String>();
		for(int i=3;i<parts.length;i=i+2)
		{
			kwds.add(parts[i]);
		}
		CandidateVertex currentVertexCand=null;
		while(minHeap.size()>0)
		{
			currentVertexCand=minHeap.poll();
//			System.out.println(currentVertexCand.id);
			//��һ�ر��� ��ֹ�ѷ��ʵģ��ٴη���
			if(queryVertexsVisited.contains(currentVertexCand.id))
			{
				continue;
			}
			
			//��ȡCurrentVertex�йص�POI
//			System.out.println(db_vertexPOIMap.size());
//			System.out.println(db_vertexEdgeMap.size());
			HashMap<Integer,POI> tmpPOIs=db_vertexPOIMap.get(currentVertexCand.id);
//			System.out.println(tmpPOIs.isEmpty());
			//�ж��Ƿ�Ϊ��
			if(tmpPOIs!=null)
			{
				for(Integer idP:tmpPOIs.keySet())
				{
						float textScore=0;
						for(int i=0;i<kwds.size();i++)
						{
							if(tmpPOIs.get(idP).textScore.containsKey(kwds.get(i)))
							{
								textScore+=tmpPOIs.get(idP).textScore.get(kwds.get(i));
							}
						}
						dataAccessed++;
//						System.out.println(textScore);
						if(textScore>=shrehod)
						{
							resultTopK.add(new CandidateResult(idP, currentVertexCand.distance));
							if(resultTopK.size()>=TopK)
							{
								return;
							}
							
						}
						
				}
			}
			
			queryVertexsVisited.add(currentVertexCand.id);
			//���������Vertex��Ϣ
			HashMap<Integer, Edge> tmpEdges=db_vertexEdgeMap.get(currentVertexCand.id);
			if(tmpEdges!=null)
			{
				for(Integer edgeID:tmpEdges.keySet())
				{
					if(!queryEdgesVisited.contains(edgeID))
					{
						if(!queryVertexsVisited.contains(tmpEdges.get(edgeID).id_vertex_end))
						{
							minHeap.add(new CandidateVertex(tmpEdges.get(edgeID).id_vertex_end, tmpEdges.get(edgeID).distance));
						}
						if(!queryVertexsVisited.contains(tmpEdges.get(edgeID).id_vertex_start))
						{
							minHeap.add(new CandidateVertex(tmpEdges.get(edgeID).id_vertex_start, tmpEdges.get(edgeID).distance));
						}
					}
					
				}
			}
		}
		
		
		
	}
	
	
	public void loadIndexDB()
	{
			
			System.out.println(DB_Baseline_Name);
			System.out.println("loadDB begin");
		
			File dbFile=new File(DB_Baseline_Name);
			DB_Baseline=DBMaker.newFileDB(dbFile)
					.transactionDisable()
					.closeOnJvmShutdown()
					.make();
			
			
			System.out.println("loadDB end");
		
		
	}

	/**
	 * @param args
	 * @throws IOException 
	 */
	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		QueryProcessing test=new QueryProcessing();
		String queryFile=LABConfig.DATA_ROOT_FOLDER_PATH+LABConfig.QUERY_FILE_FOLDER+LABConfig.dataSize+"/"+LABConfig.ROAD_NETWORK+"_DataSize_"+LABConfig.dataSize+"_kwdNum_"+LABConfig.queryNum+".txt";
		System.out.println(queryFile);
		System.out.println("K="+LABConfig.TopK);
		System.out.println("T="+LABConfig.QUERY_SHREHOD);
		test.queryFile(queryFile);
	}

}
