package org.mapdb;

/**
 * Exception thrown when transaction is rolled back.
 * @author Jan Kotek
 */
public class TxRollbackException extends RuntimeException {

}
